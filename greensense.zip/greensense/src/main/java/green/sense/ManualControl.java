package green.sense;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Switch;

public class ManualControl extends AppCompatActivity {
    Switch light1,light2,light3,light4,allLightONoff;
    Switch blinds1,blinds2,blinds3,blinds4,allBlindsONOFF;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_manual_control );
        light1=(Switch)findViewById ( R.id.Light1 );
        light2=(Switch)findViewById ( R.id.Light2 );
        light3=(Switch)findViewById ( R.id.Light3 );
        light4=(Switch)findViewById ( R.id.Light4 );

        allLightONoff=(Switch)findViewById ( R.id.allonofswitchlight );

        blinds1=(Switch)findViewById ( R.id.blinds1 );
        blinds2=(Switch)findViewById ( R.id.blinds2 );
        blinds3=(Switch)findViewById ( R.id.blinds3 );
        blinds4=(Switch)findViewById ( R.id.blinds4 );

        allBlindsONOFF=(Switch)findViewById ( R.id.allonofswitch );



    }



    public void  OutsideWeather(View view){
        Intent it1=new Intent(ManualControl.this,OutsideWeather.class);
        startActivity(it1);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater ();
        inflater.inflate ( R.menu.actionbar,menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId ()){
            case R.id.item1:
                Intent it=new Intent(ManualControl.this,Settings.class);
                startActivity(it);
                return  true;
            case R.id.item2:
                Intent it1=new Intent(ManualControl.this,Help.class);
                startActivity(it1);

                return  true;

            case R.id.item3:
                Intent it2=new Intent(ManualControl.this,Bluetooth.class);
                startActivity(it2);

                return  true;

        }
        return super.onOptionsItemSelected ( item );
    }
}
