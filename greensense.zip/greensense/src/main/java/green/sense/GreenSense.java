package green.sense;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class GreenSense extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_green_sense );



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater ();
        inflater.inflate ( R.menu.actionbar,menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId ()){
            case R.id.item1:
                Intent it=new Intent(GreenSense.this,Settings.class);
                startActivity(it);
                return  true;
            case R.id.item2:
                Intent it1=new Intent(GreenSense.this,Help.class);
                startActivity(it1);

                return  true;

            case R.id.item3:
                Intent it2=new Intent(GreenSense.this,Bluetooth.class);
                startActivity(it2);

                return  true;

        }
        return super.onOptionsItemSelected ( item );
    }


    public void  MointorTemperature(View view){
      Intent it1=new Intent(GreenSense.this,MonitorTemperature.class);
      startActivity(it1);

    }

      public void  ReadMoisture(View view){
          Intent it1=new Intent(GreenSense.this,ReadMoisture.class);
          startActivity(it1);
       }


    public void  ManualControl(View view){
        Intent it1=new Intent(GreenSense.this,ManualControl.class);
        startActivity(it1);
    }


    public void  OutsideWeather(View view){
        Intent it1=new Intent(GreenSense.this,OutsideWeather.class);
        startActivity(it1);
    }

}
