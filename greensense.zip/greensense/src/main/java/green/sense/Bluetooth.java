package green.sense;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Bluetooth extends AppCompatActivity {
    List<String> deviceList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_bluetooth );
        deviceList.add("device1");
        deviceList.add("device2");
        deviceList.add("device3");
        deviceList.add("device4");

        ListView listView=( ListView ) findViewById(R.id.list);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,deviceList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?>listview , View view, int position, long id) {
                Toast.makeText(Bluetooth.this, "only UI Developer working on backend", Toast.LENGTH_SHORT).show();
            }
        });












    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater ();
        inflater.inflate ( R.menu.actionbar,menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId ()){
            case R.id.item1:
                Intent it=new Intent(Bluetooth.this,Settings.class);
                startActivity(it);
                return  true;
            case R.id.item2:
                Intent it1=new Intent(Bluetooth.this,Help.class);
                startActivity(it1);

                return  true;

            case R.id.item3:
                Intent it2=new Intent(Bluetooth.this,Bluetooth.class);
                startActivity(it2);

                return  true;

        }
        return super.onOptionsItemSelected ( item );
    }


}
