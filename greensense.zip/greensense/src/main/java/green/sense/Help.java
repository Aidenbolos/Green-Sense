package green.sense;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class Help extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_help );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater ();
        inflater.inflate ( R.menu.actionbar,menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId ()){
            case R.id.item1:
                Intent it=new Intent(Help.this,Settings.class);
                startActivity(it);
                return  true;
            case R.id.item2:
                Intent it1=new Intent(Help.this,Help.class);
                startActivity(it1);

                return  true;

            case R.id.item3:
                Intent it2=new Intent( Help.this,Bluetooth.class);
                startActivity(it2);

                return  true;

        }
        return super.onOptionsItemSelected ( item );
    }



}
